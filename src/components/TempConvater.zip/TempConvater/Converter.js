
export const Converter = ({ value, scale }) => {
    if (scale === 'f') {
        return (value - 32) * (5 / 9);
    }
    return (value * 9 / 5) + 32;
}
