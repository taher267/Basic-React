import React, { Component } from 'react';
import { Converter } from './Converter';
import Input from './Input';

class Index extends Component {
    state = { fahrenheit: 0, celsius: 0, scale: '' }

    inputHandler = ({ target: { name, value } }) => {
        if (name === 'fahrenheit') {
            this.setState({ scale: 'f', fahrenheit: value });
            this.setState({ celsius: Converter({ name, value, scale: 'f' }) });
        } else {
            this.setState({ scale: 'c', celsius: value });
            this.setState({ fahrenheit: Converter({ name, value, scale: 'c' }) });
        }

    }
    render() {
        const { fahrenheit, celsius, scale } = this.state;
        const results = Converter({ value: scale === 'f' ? fahrenheit : celsius, scale });
        // if (scale === 'f') {
        //     // this.setState({ fahrenheit: results })
        // }


        return <div>
            {/* <Converter fahrenheit={fahrenheit} celsius={celsius} scale={scale} /> */}
            <Input name='fahrenheit' far={fahrenheit} handler={this.inputHandler} />
            <br />
            <br />
            <Input name='celsius' cel={celsius} handler={this.inputHandler} />
        </div>
    }
}

export default Index;
