const Input = ({ name, handler, far, cel }) => {
    return <fieldset style={{ display: 'flex' }}>
        <legend>{name.toUpperCase()}</legend>
        <input type='number' style={{ width: '100%' }} value={name === 'fahrenheit' ? far : cel} name={name} onChange={handler} />
    </fieldset>
}
export default Input;